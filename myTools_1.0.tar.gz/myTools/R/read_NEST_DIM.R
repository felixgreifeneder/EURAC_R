#this routine reads a NEST .dim file and returns a structure holding the information

library(date)

read_NEST_DIM <- function(path){


  #define structure
  metadata <- list(DATASET_NAME = as.character(), 
                   ACQUISITION_DATE = as.numeric(), 
                    PASS = as.character(), 
                    POLARIZATION = as.character())

  dim_file <- readLines(con=path)

  #DATASET NAME
  tmp_line <- dim_file[9]
  #tmp_line = strtrim(tmp_line, 2)
  metadata$DATASET_NAME <- substr(tmp_line, 15, 73)

  #ACQUISITION DATE
  tmp_line <- dim_file[17]
  #tmp_line = strtrim(tmp_line, 2)
  metadata$ACQUISITION_DATE <- as.numeric(as.date(substr(tmp_line, 33, 43), order="dmy")) + 2440588

  #PASS - ASCENDING/DESCENDING
  tmp_line <- dim_file[122]
  #tmp_line = strtrim(tmp_line, 2)
  metadata$PASS <- substr(tmp_line, 75, 77)

  #POLARIZATION
  tmp_line <- dim_file[124]
  #tmp_line = strtrim(tmp_line, 2)
  metadata$POLARIZATION <- substr(tmp_line, 76, 77)

  return(metadata)
